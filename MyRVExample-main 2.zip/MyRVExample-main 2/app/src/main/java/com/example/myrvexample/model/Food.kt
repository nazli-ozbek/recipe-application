package com.example.myrvexample.model

data class Food(val name: String, val type: String, val recipe: String)